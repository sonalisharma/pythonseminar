===========
CalCalc
===========

This is used to provide and ability to the usetrs to pose a query for which
this module will prvide a response. Typical usage
often looks like this::

    #!/usr/bin/env python

    from CalCalc import calculation

    calculate('34*20')

Output
=========
The output will be a number or a string based on what query you asked
